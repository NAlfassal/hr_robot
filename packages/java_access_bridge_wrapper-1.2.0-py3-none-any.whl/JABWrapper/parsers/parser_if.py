class Parser:
    def parse() -> None:
        raise NotImplementedError()

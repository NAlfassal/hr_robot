from .rpds import *

__doc__ = rpds.__doc__
if hasattr(rpds, "__all__"):
    __all__ = rpds.__all__